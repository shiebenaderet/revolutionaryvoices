# Revolutionary Voices Script Builder

An interactive tool for middle school students to create historical podcast scripts about the American Revolution.

## 🎙️ Features

- **Auto-save** - Work is saved automatically every 2 seconds
- **168+ sentence starters** - Click to insert helpful phrases
- **Word counters** - Real-time feedback on length
- **Multiple formats** - Choose from narrative, interview, news, or diary formats
- **Exemplars** - See strong examples for each section
- **Rubrics** - Clear standards for quality work
- **Time estimator** - Know how long your podcast will be

## 🚀 Live Demo

Visit: https://yourusername.github.io/revolutionary-voices/

(Replace `yourusername` with your GitHub username)

## 📖 How to Use

1. Students visit the live site
2. Fill in basic information
3. Choose introduction, content, and conclusion styles
4. Use sentence starters and verb banks for help
5. Generate complete podcast script
6. Copy to Google Docs for recording

## 🎓 For Teachers

This tool includes:
- Differentiated support (beginner to advanced sentence starters)
- Strong vs. weak writing examples
- Multiple subject perspectives (enslaved people, women, spies)
- Built-in rubrics for assessment
- Auto-save to prevent lost work

## 📝 Credits

Created for middle school Social Studies teachers and students.

## 📄 License

Free to use for educational purposes.
