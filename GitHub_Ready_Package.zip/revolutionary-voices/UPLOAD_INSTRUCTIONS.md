# 🚀 How to Upload This to GitHub (Super Simple!)

## Method 1: Drag & Drop Upload (Easiest - 3 minutes)

### Step 1: Create Your Repository
1. Go to: https://github.com/new
2. Repository name: `revolutionary-voices`
3. Description: "Student podcast script builder"
4. Make it **Public** ✅
5. Check **"Add a README file"** ✅
6. Click **"Create repository"**

### Step 2: Upload These Files
1. You're now in your new repository
2. Click **"Add file"** → **"Upload files"**
3. Drag BOTH files from this folder:
   - `index.html`
   - `README.md`
4. Or click "choose your files" and select both
5. Scroll down and click **"Commit changes"**

### Step 3: Enable GitHub Pages
1. Click **"Settings"** tab (at top)
2. Click **"Pages"** in the left sidebar
3. Under "Branch," select: **"main"**
4. Make sure **"/ (root)"** is selected
5. Click **"Save"**
6. Wait 1-2 minutes (GitHub builds your site)
7. Refresh the page
8. You'll see: **"Your site is live at https://yourusername.github.io/revolutionary-voices/"**
9. Click that link to test it!

### Step 4: Share With Students
Give them your URL:
```
https://yourusername.github.io/revolutionary-voices/
```

Replace `yourusername` with your actual GitHub username.

---

## Method 2: If You Have Git Installed (For Advanced Users)

If you're comfortable with command line:

```bash
# Navigate to this folder in terminal
cd path/to/revolutionary-voices

# Initialize git
git init

# Add files
git add .

# Commit
git commit -m "Initial commit: Revolutionary Voices Script Builder"

# Add your GitHub repo as remote (replace with your username)
git remote add origin https://github.com/yourusername/revolutionary-voices.git

# Push to GitHub
git branch -M main
git push -u origin main
```

Then enable GitHub Pages in Settings → Pages.

---

## 🎉 You're Done!

Your tool is now live and ready for students!

**To Update Later:**
1. Go to your repository on GitHub
2. Click on `index.html`
3. Click the pencil icon (Edit)
4. Make changes
5. Scroll down and click "Commit changes"
6. Your site updates automatically in 1-2 minutes!

---

## 🆘 Need Help?

- GitHub Guides: https://guides.github.com/
- GitHub Pages Docs: https://pages.github.com/
- Or just ask me! 😊
